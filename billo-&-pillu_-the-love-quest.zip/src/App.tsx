import { useCallback, useEffect, useRef, useState } from "react";
import { sounds } from "./utils/audio";

type Screen = "title" | "opening" | "map" | "game" | "ending";
type Memory = { label: string; text: string };
type Chapter = {
  title: string;
  region: string;
  place: string;
  tone: string;
  icon: string;
  memories: Memory[];
};

const chapters: Chapter[] = [
  {
    title: "Who's That Guy?",
    region: "Before Us",
    place: "Seoni • Nagpur • Mumbai",
    tone: "rose",
    icon: "portrait",
    memories: [
      {
        label: "A bright beginning",
        text: "Prateek Shrivastav was born on 8 February in Seoni, Madhya Pradesh—the first child of Pradeep and Preeti, and elder brother to Pragati, fondly called Khushi.",
      },
      {
        label: "A wider world",
        text: "Ambitious, romantic, and always dreaming beyond his small city, he left Seoni for Nagpur and later moved to Mumbai for business school, choosing growth after heartbreak.",
      },
      {
        label: "The unwritten story",
        text: "Hostel laughter, late-night dreams, and a fierce focus on success filled his days. Still, his heart quietly waited for connection and meaning.",
      },
    ],
  },
  {
    title: "Who's That Girl?",
    region: "Before Us",
    place: "Bandra • Thane • Vivekanand",
    tone: "lavender",
    icon: "portrait",
    memories: [
      {
        label: "A small storm",
        text: "Shruti Bhosle was born on 27 February 2004 in Bandra and raised in Thane—the elder daughter of Rakesh and Nita, and sister to Shreya.",
      },
      {
        label: "The quiet glow-up",
        text: "Once loud, fearless, and mischievous, lockdown made her softer and inward-looking. She found new worlds in politics, horror, and true crime.",
      },
      {
        label: "A new direction",
        text: "Unsure of the future but craving purpose, she impulsively chose an MBA at Vivekanand—and carried a quiet hope for something steady, safe, and real.",
      },
    ],
  },
  {
    title: "More Than Just a Performance",
    region: "The Dance That Started It",
    place: "Vivekanand",
    tone: "midnight",
    icon: "music",
    memories: [
      {
        label: "Built to move",
        text: "Prateek came to Vivekanand focused on success, but music was where he felt completely himself. The stage never scared him.",
      },
      {
        label: "A simple yes",
        text: "When a new friend asked if he wanted to join a group dance performance, his answer came naturally: yes.",
      },
      {
        label: "More than a dance",
        text: "He thought he was signing up for choreography and practice. He had no idea the performance would change everything.",
      },
    ],
  },
  {
    title: "When Destiny Joined the Team",
    region: "The Dance That Started It",
    place: "Practice room",
    tone: "lavender",
    icon: "music",
    memories: [
      {
        label: "Pulled onto the floor",
        text: "On her first day, a bubbly new friend impulsively signed Shruti up for a college dance performance, then had to back out.",
      },
      {
        label: "One dancer short",
        text: "Shruti pushed the remaining team to rehearse seriously, but the formations could not work without one strong dancer.",
      },
      {
        label: "The missing piece",
        text: "She asked her partner to find someone genuinely good. The person who walked into the practice room became the biggest surprise of all.",
      },
    ],
  },
  {
    title: "Unexpectedly Intrigued",
    region: "The Dance That Started It",
    place: "Rehearsal studio",
    tone: "rose",
    icon: "phone",
    memories: [
      {
        label: "Just a casual hello",
        text: "Prateek arrived thinking only about dance and an upcoming trip to his mama’s place in Nashik. He thought Shruti was cute and got to work.",
      },
      {
        label: "Jhali",
        text: "Her mischievous, playful, completely unfiltered energy stood out. By the end of practice he had a word for her: jhali—wild in the best way.",
      },
      {
        label: "No hesitation",
        text: "She handed him her phone and told him to add his number to the group. Her fearless ease intrigued him more than he expected.",
      },
    ],
  },
  {
    title: "The One in Pink",
    region: "The Dance That Started It",
    place: "Rehearsal studio",
    tone: "pink",
    icon: "shirt",
    memories: [
      {
        label: "The pink shirt",
        text: "Shruti first noticed his pink shirt, then his warm eyes, honey-sweet smile, beard, and earrings. To her, he was the prettiest boy she had ever seen.",
      },
      {
        label: "Patient and kind",
        text: "He treated everyone like old friends and stayed calm and patient while she learned the dance. She thought he was the sweetest boy she had met.",
      },
      {
        label: "Prateek",
        text: "She wanted to know him and make a connection. The boy in the pink shirt had a name: Prateek.",
      },
    ],
  },
  {
    title: "Calls, Texts, and Lip Gloss",
    region: "The Dance That Started It",
    place: "Between rehearsals",
    tone: "cherry",
    icon: "phone",
    memories: [
      {
        label: "8:30 in the morning",
        text: "Shruti scheduled practice for 8:30 a.m. and called Prateek after knowing him for barely two days. Sleep-loving Prateek found it ridiculous—and intriguing.",
      },
      {
        label: "Messages after practice",
        text: "Practice conversations became texts, replies came quicker, and they followed each other on Instagram.",
      },
      {
        label: "The lip gloss picture",
        text: "While traveling to his mama’s place, Prateek kept returning to a photo of Shruti in beautiful lip gloss. He began looking forward to her more than the dance.",
      },
    ],
  },
  {
    title: "Small Gestures, Big Feelings",
    region: "The Dance That Started It",
    place: "An empty practice room",
    tone: "rose",
    icon: "drink",
    memories: [
      {
        label: "No one came",
        text: "Shruti arrived at 8:30 a.m. for practice. No one else did—not even Prateek, despite her calls. For a moment, her dreamy image of him cracked.",
      },
      {
        label: "He noticed",
        text: "Later, Prateek quietly noticed she was tired and on her period, and brought her energy drinks without making it awkward.",
      },
      {
        label: "Closer from afar",
        text: "He left for his mama’s place, but their messages kept flowing. As dance day approached, so did they.",
      },
    ],
  },
  {
    title: "The Hug That Stayed",
    region: "The Dance That Started It",
    place: "College auditorium",
    tone: "midnight",
    icon: "stage",
    memories: [
      {
        label: "Stage fright",
        text: "Shruti took off her glasses and performed despite trembling hands, racing thoughts, and anxiety. Afterward, she rushed out and sat on the floor to steady herself.",
      },
      {
        label: "A grounding hand",
        text: "Prateek put a gentle hand on her shoulder, stayed with her, and offered a side hug that felt exactly right.",
      },
      {
        label: "A quiet challenge",
        text: "Knowing he wanted to see her in a Maharashtrian saree, she wore her mother’s saree to the Satya Narayan pooja the next day.",
      },
    ],
  },
  {
    title: "A Dream He Didn't Know He Had",
    region: "The Dance That Started It",
    place: "College garden",
    tone: "maroon",
    icon: "flower",
    memories: [
      {
        label: "Maroon and gold",
        text: "Prateek saw Shruti in a deep maroon saree, chandrakor bindi, kamarband, bangles, and nathi—and everything else disappeared.",
      },
      {
        label: "Still herself",
        text: "She looked timeless and breathtaking, yet still cute, shy, quirky, and playful. That contrast made her irresistible to him.",
      },
      {
        label: "Her head on his shoulder",
        text: "Later, she rested her head on his shoulder for the first time. His heart forgot how to beat, and he knew this could become special.",
      },
    ],
  },
  {
    title: "The Moment Before the Moment",
    region: "The Dance That Started It",
    place: "A friend's sleepover",
    tone: "lavender",
    icon: "moon",
    memories: [
      {
        label: "Taking it slow",
        text: "They spoke honestly about their pasts and what love meant to them. A misunderstanding about keeping things casual hurt, but they talked it through.",
      },
      {
        label: "Her first night out",
        text: "Shruti convinced her parents to allow a sleepover. The night was full of songs, laughter, and random conversations.",
      },
      {
        label: "The 4 a.m. call",
        text: "Around four or five in the morning, Prateek called from the room outside and asked her to come out. She knew something precious was waiting.",
      },
    ],
  },
  {
    title: "The First Kiss — His, I",
    region: "The First Kiss",
    place: "The room outside",
    tone: "midnight",
    icon: "teddy",
    memories: [
      {
        label: "Wanting to be close",
        text: "Prateek hoped the sleepover would bring quiet time together. Physical closeness was how he expressed affection, but Shruti valued her space.",
      },
      {
        label: "Unable to sleep",
        text: "The room outside was cramped. Restless and disappointed, he texted, then called Shruti.",
      },
      {
        label: "The door opened",
        text: "He assumed she was asleep. Then the door opened, and there she was.",
      },
    ],
  },
  {
    title: "The First Kiss — His, II",
    region: "The First Kiss",
    place: "Early morning",
    tone: "cherry",
    icon: "teddy",
    memories: [
      {
        label: "The koala bear",
        text: "Shruti let him lie beside her. He playfully stole both soft toys until she curled up against him like a little koala bear.",
      },
      {
        label: "A cheek kiss",
        text: "Tiny fingers brushed his face, then she placed a soft kiss on his cheek. They moved closer until almost no space remained.",
      },
      {
        label: "The trial round",
        text: "She said she wanted to kiss him but not ruin their first kiss. He grinned: “We can always have a trial round before the start.” She smiled—and kissed him.",
      },
    ],
  },
  {
    title: "The First Kiss — Her, I",
    region: "The First Kiss",
    place: "Beside him",
    tone: "lavender",
    icon: "teddy",
    memories: [
      {
        label: "Not the teddy",
        text: "When Prateek took one teddy and then the other, Shruti understood: he did not want the teddy. He wanted her.",
      },
      {
        label: "Safe",
        text: "She turned, curled up beside him, and felt warm, calm, and unexpectedly peaceful. She drifted off like a baby.",
      },
      {
        label: "A quiet morning",
        text: "Waking later, she watched his soft breathing and peaceful face, fascinated that he was right there beside her.",
      },
    ],
  },
  {
    title: "The First Kiss — Her, II",
    region: "The First Kiss",
    place: "The space between them",
    tone: "cherry",
    icon: "spark",
    memories: [
      {
        label: "Memorizing him",
        text: "Shruti traced his cheek and nose, wanting to memorize every detail. The moment felt intimate and precious.",
      },
      {
        label: "Just because",
        text: "She held back from his lips and kissed his cheek instead. When he woke, she whispered, “Just because I felt like it.”",
      },
      {
        label: "Everything changed",
        text: "She admitted how much she wanted to kiss him. His playful honesty melted her hesitation, and she kissed him sincerely. Something changed forever.",
      },
    ],
  },
  {
    title: "A Ganpati Bappa Blessing",
    region: "Festivals & Becoming Us",
    place: "Chinchpokali • Khetwadi",
    tone: "saffron",
    icon: "temple",
    memories: [
      {
        label: "Matching perfectly",
        text: "For his first Ganesh Chaturthi in Mumbai, Prateek wore blue and Shruti wore red with blue bangles. They contrasted, yet matched perfectly.",
      },
      {
        label: "One prayer",
        text: "At Chinchpokali Cha Chintamani they offered a नारळ together, asking Bappa to bless and guide their new relationship.",
      },
      {
        label: "Mumbai in colour",
        text: "They explored the Khetwadi pandals with friends. Prateek hoped it was the beginning of a lifetime of festivals with his Billo.",
      },
    ],
  },
  {
    title: "Pink, White & A Little Bit of Garba",
    region: "Festivals & Becoming Us",
    place: "College Navratri",
    tone: "pink",
    icon: "music",
    memories: [
      {
        label: "Matching again",
        text: "Shruti wore a pink-and-white kurti with jeans. Prateek arrived in a white kurta, jeans, and a pink chunni to match her.",
      },
      {
        label: "Their own steps",
        text: "She barely knew Garba and he was a pro, so they danced randomly and made their own fun beneath the college lights.",
      },
      {
        label: "Worth the scolding",
        text: "The night ran late; Shruti missed calls and fell asleep in the cab. Despite the scoldings, she had the best time with her favourite Garba partner.",
      },
    ],
  },
  {
    title: "A Diwali With Something Missing",
    region: "Festivals & Becoming Us",
    place: "Two homes, one longing",
    tone: "midnight",
    icon: "lamp",
    memories: [
      {
        label: "Growing closer",
        text: "Studying, laughing, and spending time together had made them each other’s favourite person and safest little world.",
      },
      {
        label: "The longest apart",
        text: "Prateek went home for Diwali. They exchanged gifts, celebrated with family, and felt the ache of missing someone from every familiar ritual.",
      },
      {
        label: "November waited",
        text: "Calls and messages replaced their everyday closeness. Neither knew that November held something beautiful enough to make the waiting worthwhile.",
      },
    ],
  },
  {
    title: "The Day We Became Us",
    region: "Festivals & Becoming Us",
    place: "Marine Lines • 7 Nov 2025",
    tone: "ocean",
    icon: "flower",
    memories: [
      {
        label: "By the sea",
        text: "Back in Mumbai, Prateek planned a meaningful evening at Marine Lines and asked Shruti what being together meant to her.",
      },
      {
        label: "A flower and a question",
        text: "She had asked him to bring her a flower. With the sea before them, he asked her to be his girlfriend.",
      },
      {
        label: "Choosing us",
        text: "On 7 November 2025, they became more than two people wondering what they could be: two hearts choosing to walk together.",
      },
    ],
  },
  {
    title: "Our Little Adventure in the Woods",
    region: "Dates & New Beginnings",
    place: "Sanjay Gandhi National Park",
    tone: "forest",
    icon: "cycle",
    memories: [
      {
        label: "Made with love",
        text: "On 8 November, Prateek packed herb rice with peri-peri gravy, drinks, and desserts for their first adventure picnic date.",
      },
      {
        label: "Toward Kanheri",
        text: "They rented cycles in Borivali, rode through the greenery, explored Kanheri Caves, and shared their picnic in nature.",
      },
      {
        label: "The last seat",
        text: "On the AC bus back to Thane, they cuddled and shared their second kiss. Ordinary moments felt extraordinary with Pillu beside him.",
      },
    ],
  },
  {
    title: "Our Little Getaway",
    region: "Dates & New Beginnings",
    place: "A cosy room • McDonald’s",
    tone: "rose",
    icon: "key",
    memories: [
      {
        label: "A world for two",
        text: "Instead of another hectic Aarohan fest day, they booked a one-night stay and filled it with cuddles, games, laughter, and conversation.",
      },
      {
        label: "Street-food evening",
        text: "They stepped out for street food, then returned to the warmth of their little room—until sleepy Shruti chose sleep.",
      },
      {
        label: "One more meal",
        text: "The next morning, they stretched out goodbye over McDonald’s. The getaway proved his favourite place was wherever Billo was.",
      },
    ],
  },
  {
    title: "Coffee, Calls & A New Beginning",
    region: "Dates & New Beginnings",
    place: "December study nights",
    tone: "coffee",
    icon: "book",
    memories: [
      {
        label: "Coffee and Google Meets",
        text: "Exam season meant books, notes, late-night study sessions, coffee, and Google Meets. They taught each other and laughed through the syllabus.",
      },
      {
        label: "First prize",
        text: "Their work on a research paper won first prize at the conference—a proud reminder of what they could achieve side by side.",
      },
      {
        label: "Hello, January",
        text: "The new year brought lectures and fresh hopes, while February waited with both birthdays and Valentine’s Day.",
      },
    ],
  },
  {
    title: "Tears, Gifts & A Birthday to Remember",
    region: "Dates & New Beginnings",
    place: "Cosy café • Namo Garden",
    tone: "blue",
    icon: "gift",
    memories: [
      {
        label: "The first big fight",
        text: "A celebration with friends on 7 February became their first really big fight. Emotions ran high, and both ended the day hurt and crying.",
      },
      {
        label: "Choosing to understand",
        text: "On Prateek’s birthday they met at a quiet café, spoke honestly through tears, and found their way back to each other.",
      },
      {
        label: "The real gift",
        text: "Shruti’s thoughtful gifts and their walk at Namo Garden made him feel deeply loved. The greatest gift was Billo choosing them when things were hard.",
      },
    ],
  },
  {
    title: "A Birthday Wrapped in Love",
    region: "Dates & New Beginnings",
    place: "Andheri • Silver Beach • ISKCON",
    tone: "cherry",
    icon: "cake",
    memories: [
      {
        label: "A low-key Valentine’s",
        text: "They celebrated early after college with gifts at the food court, turning an ordinary place into something special.",
      },
      {
        label: "Midnight magic",
        text: "For Shruti’s birthday they returned to the Andheri hotel, walked Silver Beach, visited ISKCON Temple, and welcomed midnight at a corner Prateek lovingly prepared.",
      },
      {
        label: "Her quiet prayer",
        text: "After a night of cuddles, laughter, and deep conversations, Shruti wished to celebrate countless more birthdays with her love.",
      },
    ],
  },
  {
    title: "Colours, Chaos & My Billo",
    region: "Growing Side by Side",
    place: "Holi in Thane",
    tone: "colour",
    icon: "drop",
    memories: [
      {
        label: "A surprise arrival",
        text: "For his first Holi with Shruti, Prateek surprised her by taking a bus to her society and meeting her childhood friends.",
      },
      {
        label: "Pure madness",
        text: "Colours, rain dancing, laughter, and festive chaos made it one of his most happening celebrations.",
      },
      {
        label: "Back to the books",
        text: "April brought exams again. From celebrating colours to conquering study stress, they remained each other’s strongest support.",
      },
    ],
  },
  {
    title: "Side by Side, Through It All",
    region: "Growing Side by Side",
    place: "Aabo internship",
    tone: "blue",
    icon: "briefcase",
    memories: [
      {
        label: "First interviews",
        text: "As a fresher, Shruti was nervous about internship placements. Pillu stayed beside her, reminding her what she could do.",
      },
      {
        label: "Both at Aabo",
        text: "Prateek was selected at Aabo. When another opening appeared, Shruti interviewed and was selected too.",
      },
      {
        label: "Three months together",
        text: "Their internship held learning, work, jokes, and countless everyday memories—until a tragedy changed the shape of Girlfriends’ Day.",
      },
    ],
  },
  {
    title: "The Day Everything Changed",
    region: "Growing Side by Side",
    place: "Girlfriends’ Day",
    tone: "rain",
    icon: "clay",
    memories: [
      {
        label: "A day prepared with love",
        text: "Prateek welcomed Shruti with flowers, singing, and a clay-figure date. For a while, the day felt perfect.",
      },
      {
        label: "The call",
        text: "Then came the news that his grandfather, who had been living with cancer, had passed away. He had shaped Prateek’s childhood and inspired the man he wanted to become.",
      },
      {
        label: "Not alone",
        text: "Prateek broke down in Shruti’s arms. She stayed, comforted him, and helped book tickets home—reminding him he did not have to face the pain alone.",
      },
    ],
  },
  {
    title: "A Little More Time Together",
    region: "Growing Side by Side",
    place: "Thane • Home",
    tone: "rose",
    icon: "home",
    memories: [
      {
        label: "Holding space",
        text: "When Pillu returned, Shruti knew grief would remain. She could not remove it, but she could hold him and make sure he never carried it alone.",
      },
      {
        label: "Ordinary, extraordinary",
        text: "After he shifted to Thane, they had more time at home—days and nights of talking, laughing, and simply being themselves.",
      },
      {
        label: "Back to college",
        text: "College eventually restarted. After internship life, lectures felt a little “meh,” but even returning to routine had joy with Pillu beside her.",
      },
    ],
  },
  {
    title: "Bappa, Blessings & My Billo",
    region: "Growing Side by Side",
    place: "Lalbaug • Chinchpokali • Khetwadi",
    tone: "saffron",
    icon: "temple",
    memories: [
      {
        label: "A familiar blessing",
        text: "Healing slowly, Prateek returned with Shruti to Lalbaug and Chinchpokali for his second Ganesh Chaturthi away from home.",
      },
      {
        label: "One year later",
        text: "Chinchpokali brought back their first festival as a new couple. Now their gratitude held a whole year of happiness and challenges.",
      },
      {
        label: "Mumbai became home",
        text: "Khetwadi pandals and darshan with Shruti’s friends felt warm and familiar. Being part of her world made Mumbai feel like his too.",
      },
    ],
  },
  {
    title: "Bangkok After Dark",
    region: "Thailand",
    place: "Bangkok • Thailand",
    tone: "bangkok",
    icon: "plane",
    memories: [
      {
        label: "A shared first",
        text: "Thailand was the first international trip for both of them. They had imagined sharing it, but were not able to experience the full adventure side by side.",
      },
      {
        label: "Mixed feelings",
        text: "Shruti struggled to enjoy the trip without Pillu and felt unsupported by friends; Prateek explored what he could while missing her dearly.",
      },
      {
        label: "Their Bangkok night",
        text: "One late night they found a café together, tried their first hard-liquor drinks, wandered the streets tipsy and laughing, and stopped at Seven Eleven for chips. That simple night became truly theirs.",
      },
    ],
  },
  {
    title: "Aptitude, Adrenaline & A Whole Lot of Love",
    region: "Toward One Year",
    place: "Tembinaka Devi • Navratri mela",
    tone: "nightfair",
    icon: "wheel",
    memories: [
      {
        label: "Through self-doubt",
        text: "After Prateek did not clear an interview aptitude round, anxiety took hold. Shruti reminded him of his ability, and together they refocused on their futures.",
      },
      {
        label: "A meal and blessings",
        text: "For Navratri they visited Tembinaka Devi, offered a naral, explored the mela stalls, and shared street food.",
      },
      {
        label: "Love on the dragon ride",
        text: "They both regretted the terrifying dragon ride. Shruti clung to Pillu and confessed her love to distract them, then said it again safely on the ground. He ended the evening by getting her two balloons.",
      },
    ],
  },
];

const MAP_PAGE_SIZE = 5;
const MAP_PAGE_COUNT = Math.ceil(chapters.length / MAP_PAGE_SIZE);

const ICONS: Record<string, string> = {
  portrait: "M12 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm-7 16c0-4 3-6 7-6s7 2 7 6",
  music:
    "M9 17V5l10-2v12M9 17a3 3 0 1 1-3-3 3 3 0 0 1 3 3Zm10-2a3 3 0 1 1-3-3 3 3 0 0 1 3 3ZM9 9l10-2",
  phone: "M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Zm3 15h2",
  shirt: "m8 4-5 4 3 4 2-2v10h8V10l2 2 3-4-5-4c-1 2-7 2-8 0Z",
  drink: "M7 8h10l-1 12H8L7 8Zm2-4 3 4 4-5",
  stage: "M3 18h18M6 18V6h12v12M9 12l2 2 4-5",
  flower: "M12 12c-6-2-6-8-2-8 2 0 2 4 2 4s0-4 2-4c4 0 4 6-2 8Zm0 0v9m0-5 4-2",
  moon: "M19 15A8 8 0 0 1 9 5a8 8 0 1 0 10 10Z",
  teddy:
    "M8 8a3 3 0 1 1 1-5 7 7 0 0 1 6 0 3 3 0 1 1 1 5c2 2 2 9-4 9s-6-7-4-9Zm1 5h.01M15 13h.01M10 9h4",
  spark: "m12 2 1.5 6.5L20 10l-6.5 1.5L12 18l-1.5-6.5L4 10l6.5-1.5L12 2Z",
  temple: "M4 20h16M6 20v-8h12v8M4 12h16L12 4 4 12Zm6 8v-4h4v4",
  lamp: "M7 12h10c0 4-2 7-5 7s-5-3-5-7Zm5 0V8c0-2 2-2 2-4",
  cycle:
    "M6 18a4 4 0 1 1 0-8 4 4 0 0 1 0 8Zm12 0a4 4 0 1 1 0-8 4 4 0 0 1 0 8ZM6 14l4-7h4l4 7m-8-7 4 7H6",
  key: "M15 8a5 5 0 1 1-2 4l-8 8-2-2 2-2-1-1 2-2 1 1 2-2",
  book: "M4 5c3-1 6 0 8 2v13c-2-2-5-3-8-2V5Zm16 0c-3-1-6 0-8 2v13c2-2 5-3 8-2V5Z",
  gift: "M4 10h16v10H4V10Zm-1-4h18v4H3V6Zm9 0c-5 0-5-5-2-5 2 0 2 5 2 5Zm0 0c5 0 5-5 2-5-2 0-2 5-2 5Zm0 0v14",
  cake: "M5 12h14v8H5v-8Zm2-4h10v4H7V8Zm5 0V4m-1 0 1-2 1 2",
  drop: "M12 3S6 10 6 14a6 6 0 0 0 12 0c0-4-6-11-6-11Z",
  briefcase: "M4 8h16v11H4V8Zm5 0V5h6v3m-11 5c5 2 11 2 16 0",
  clay: "M7 18c0-4 2-7 5-7s5 3 5 7H7Zm2-11a3 3 0 1 0 6 0 3 3 0 0 0-6 0Z",
  home: "m3 11 9-8 9 8v10h-6v-6H9v6H3V11Z",
  plane: "m3 13 18-9-7 16-2-6-6-2-3 1Zm9 1 9-10",
  wheel: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm0 0v18m-9-9h18M6 6l12 12m0-12L6 18",
};

function Icon({ name, size = 24 }: { name: string; size?: number }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="square"
      strokeLinejoin="miter"
      aria-hidden="true"
    >
      <path d={ICONS[name] || ICONS.spark} />
    </svg>
  );
}

function PixelCouple({
  small = false,
  walking = false,
  holdingHands = true,
}: {
  small?: boolean;
  walking?: boolean;
  holdingHands?: boolean;
}) {
  const isHoldingHands = holdingHands && !walking;

  if (isHoldingHands) {
    return (
      <div
        className={`pixel-couple couple-holding-hands ${small ? "small" : ""}`}
        aria-label="Pixel art Pillu and Billo holding hands"
      >
        <div className="couple-sprite">
          <span className="character-name pillu-label">PILLU</span>
          <span className="between-heart">♥</span>
          <span className="character-name billo-label">BILLO</span>
          <img src="/characters/couple.png" alt="Pillu and Billo holding hands" draggable="false" />
        </div>
      </div>
    );
  }

  return (
    <div
      className={`pixel-couple ${small ? "small" : ""} ${walking ? "walking" : ""}`}
      aria-label="Pixel art Billo and Pillu standing together"
    >
      <div className="character-sprite pillu-sprite">
        <span className="character-name">PILLU</span>
        <img src="/characters/pillu.png" alt="Pillu (Prateek)" draggable="false" />
      </div>
      <span className="between-heart">♥</span>
      <div className="character-sprite billo-sprite">
        <span className="character-name">BILLO</span>
        <img src="/characters/billo.png" alt="Billo (Shruti)" draggable="false" />
      </div>
    </div>
  );
}

function Stars() {
  return (
    <div className="stars" aria-hidden="true">
      {Array.from({ length: 28 }, (_, i) => (
        <i
          key={i}
          style={{
            left: `${(i * 37) % 97}%`,
            top: `${(i * 61) % 81}%`,
            animationDelay: `${(i % 7) * 0.24}s`,
          }}
        />
      ))}
    </div>
  );
}

function Controls({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`controls ${compact ? "compact" : ""}`}>
      <span>
        <kbd>WASD</kbd>
        <kbd>↑↓←→</kbd> MOVE
      </span>
      <span>
        <kbd>ENTER</kbd> INTERACT
      </span>
      <span>
        <kbd>ESC</kbd> PAUSE
      </span>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("title");
  const [active, setActive] = useState(0);
  const [completed, setCompleted] = useState<number[]>(() => {
    try {
      return JSON.parse(localStorage.getItem("loveQuestProgress") || "[]");
    } catch {
      return [];
    }
  });
  const [paused, setPaused] = useState(false);
  const [memory, setMemory] = useState<number | null>(null);
  const [openingPage, setOpeningPage] = useState(0);
  const [mapPage, setMapPage] = useState(0);
  const [pos, setPos] = useState({ x: 48, y: 68 });
  const [facing, setFacing] = useState<"left" | "right">("right");
  const [isMoving, setIsMoving] = useState(false);
  const [muted, setMuted] = useState(() => sounds.isMuted());
  const [whisper, setWhisper] = useState<string | null>(null);
  const moveTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    localStorage.setItem("loveQuestProgress", JSON.stringify(completed));
  }, [completed]);

  const unlocked = Math.min(chapters.length - 1, completed.length ? Math.max(...completed) + 1 : 0);
  const canContinue = completed.length > 0;
  const chapter = chapters[active];
  const visibleChapters = chapters.slice(mapPage * MAP_PAGE_SIZE, (mapPage + 1) * MAP_PAGE_SIZE);

  const distOne = Math.hypot(pos.x - 25, pos.y - 52);
  const isNearObjectOne = distOne < 22;
  const distTwo = Math.hypot(pos.x - 77, pos.y - 38);
  const isNearObjectTwo = distTwo < 20;

  const triggerWhisper = useCallback(() => {
    sounds.playWhisper();
    const quotes = [
      "Every step led us right to each other.",
      "The boy in the pink shirt and the girl who danced into his life.",
      "Pillu & Billo: always side by side, through everything.",
      "Not just a love story—our adventure.",
      "One year down, an entire lifetime to go."
    ];
    const quote = chapter.memories[0]?.label || quotes[active % quotes.length];
    setWhisper(`✨ Secret Sparkle: "${quote}" 💕`);
    setTimeout(() => setWhisper(null), 3500);
  }, [chapter, active]);

  const beginChapter = useCallback(
    (index: number) => {
      if (index > unlocked) return;
      sounds.playChime();
      setActive(index);
      setPos({ x: 48, y: 68 });
      setFacing("right");
      setIsMoving(false);
      setMemory(null);
      setPaused(false);
      setWhisper(null);
      setScreen("game");
    },
    [unlocked],
  );

  const finishChapter = useCallback(() => {
    sounds.playFanfare();
    setCompleted((old) => (old.includes(active) ? old : [...old, active]));
    setMemory(null);
    if (active === chapters.length - 1) setScreen("ending");
    else {
      setMapPage(Math.floor((active + 1) / MAP_PAGE_SIZE));
      setScreen("map");
    }
  }, [active]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && screen !== "title") {
        e.preventDefault();
        sounds.playBeep();
        setPaused((v) => !v);
        return;
      }
      if (paused) return;
      if (screen === "opening" && (e.key === "Enter" || e.code === "Space")) {
        e.preventDefault();
        sounds.playBeep();
        if (openingPage < 2) setOpeningPage((p) => p + 1);
        else {
          setMapPage(0);
          setScreen("map");
        }
        return;
      }
      if (screen === "map") {
        if (e.key === "ArrowLeft") {
          sounds.playBeep();
          setMapPage((page) => Math.max(0, page - 1));
        }
        if (e.key === "ArrowRight") {
          sounds.playBeep();
          setMapPage((page) => Math.min(MAP_PAGE_COUNT - 1, page + 1));
        }
        return;
      }
      if (screen !== "game") return;
      if (memory !== null) {
        if (e.key === "Enter" || e.code === "Space" || e.key === "ArrowRight") {
          e.preventDefault();
          sounds.playBeep();
          if (memory < chapter.memories.length - 1) setMemory((m) => (m ?? 0) + 1);
          else finishChapter();
        } else if (e.key === "ArrowLeft") {
          e.preventDefault();
          sounds.playBeep();
          if (memory > 0) setMemory((m) => (m ?? 1) - 1);
        }
        return;
      }
      const step = 4;
      let moved = false;
      if (["ArrowUp", "w", "W"].includes(e.key)) {
        setPos((p) => ({ ...p, y: Math.max(20, p.y - step) }));
        moved = true;
      }
      if (["ArrowDown", "s", "S"].includes(e.key)) {
        setPos((p) => ({ ...p, y: Math.min(78, p.y + step) }));
        moved = true;
      }
      if (["ArrowLeft", "a", "A"].includes(e.key)) {
        setPos((p) => ({ ...p, x: Math.max(5, p.x - step) }));
        setFacing("left");
        moved = true;
      }
      if (["ArrowRight", "d", "D"].includes(e.key)) {
        setPos((p) => ({ ...p, x: Math.min(92, p.x + step) }));
        setFacing("right");
        moved = true;
      }
      if (moved) {
        setIsMoving(true);
        sounds.playStep();
        if (moveTimerRef.current) clearTimeout(moveTimerRef.current);
        moveTimerRef.current = setTimeout(() => setIsMoving(false), 220);
      }
      if (e.key === "Enter" || e.code === "Space") {
        e.preventDefault();
        const dTwo = Math.hypot(pos.x - 77, pos.y - 38);
        if (dTwo < 20) {
          triggerWhisper();
          return;
        }
        sounds.playChime();
        setMemory(0);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [screen, paused, memory, chapter, openingPage, finishChapter, pos, triggerWhisper]);

  const openingCopy = [
    [
      "A STORY WRITTEN IN SMALL MOMENTS",
      "Before there was Billo & Pillu, there were two lives finding their way to the same practice room. One from Seoni. One from Thane. Both carrying dreams they had not yet shared.",
    ],
    [
      "THEN THE MUSIC STARTED",
      "A missing dancer. A pink shirt. An 8:30 a.m. rehearsal. Calls, texts, a lip-gloss picture—and a gentle hand that stayed when anxiety grew loud.",
    ],
    [
      "THIS IS OUR FIRST YEAR",
      "Not a perfect story. A real one: festivals and forest trails, tears and trophies, Bangkok after dark, and the everyday choice to stay side by side.",
    ],
  ];

  return (
    <main className="app-shell">
      {screen === "title" && (
        <section className="screen title-screen">
          <Stars />
          <div className="moon-glow" />
          <div className="title-ornament">
            <span /> PLAYER ONE + PLAYER TWO <span />
          </div>
          <div className="logo-block">
            <p>AN ANNIVERSARY ADVENTURE</p>
            <h1>
              <span>
                BILLO <i>&</i> PILLU
              </span>
              <strong>THE LOVE QUEST</strong>
            </h1>
            <div className="level-ribbon">LEVEL 1&nbsp;: ONE YEAR OF US</div>
          </div>
          <div className="title-landscape">
            <div className="city city-back" />
            <div className="city city-front" />
            <div className="ground" />
            <PixelCouple />
          </div>
          <div className="title-actions">
            <button
              className="pixel-button primary"
              onClick={() => {
                sounds.playBeep();
                setOpeningPage(0);
                setScreen("opening");
              }}
            >
              <span>▶</span> START GAME
            </button>
            <button
              className="pixel-button secondary"
              disabled={!canContinue}
              onClick={() => {
                sounds.playBeep();
                setMapPage(Math.floor(unlocked / MAP_PAGE_SIZE));
                setScreen("map");
              }}
            >
              CONTINUE <small>{canContinue ? `${completed.length}/31` : "NO SAVE DATA"}</small>
            </button>
          </div>
          <Controls compact />
          <div style={{ marginTop: "8px", display: "flex", justifyContent: "center" }}>
            <button
              className="sound-toggle-btn"
              onClick={() => {
                const next = sounds.toggleMute();
                setMuted(next);
              }}
              title={muted ? "Unmute audio" : "Mute audio"}
            >
              {muted ? "🔇 SFX OFF" : "🔊 SFX ON"}
            </button>
          </div>
          <p className="save-note">PROGRESS SAVES AUTOMATICALLY</p>
        </section>
      )}

      {screen === "opening" && (
        <section className="screen opening-screen">
          <Stars />
          <header className="game-header">
            <button
              className="back-link"
              onClick={() => {
                sounds.playBeep();
                setScreen("title");
              }}
            >
              ← TITLE
            </button>
            <span>PROLOGUE</span>
            <div className="header-actions">
              <button
                className="sound-toggle-btn"
                onClick={() => {
                  const next = sounds.toggleMute();
                  setMuted(next);
                }}
                title={muted ? "Unmute audio" : "Mute audio"}
              >
                {muted ? "🔇 SFX OFF" : "🔊 SFX ON"}
              </button>
              <button
                className="icon-button"
                onClick={() => {
                  sounds.playBeep();
                  setPaused(true);
                }}
              >
                II
              </button>
            </div>
          </header>
          <div className="cinema">
            <div className="scene-window">
              <div className="distant-city" />
              <div className="spotlight" />
              <PixelCouple />
              <div className="film-grain" />
            </div>
            <div
              className="dialogue-box cinematic-box"
              onClick={() => {
                sounds.playBeep();
                if (openingPage < 2) setOpeningPage((p) => p + 1);
                else {
                  setMapPage(0);
                  setScreen("map");
                }
              }}
            >
              <div className="speaker">OUR STORY</div>
              <h2>{openingCopy[openingPage][0]}</h2>
              <p>{openingCopy[openingPage][1]}</p>
              <div className="dialogue-footer">
                <span>{openingPage + 1} / 3</span>
                <b>PRESS ENTER TO {openingPage === 2 ? "BEGIN" : "CONTINUE"} ▼</b>
              </div>
            </div>
          </div>
        </section>
      )}

      {screen === "map" && (
        <section className="screen map-screen">
          <header className="game-header map-header">
            <div>
              <span className="eyebrow">LEVEL 1</span>
              <h2>MEMORY MAP</h2>
            </div>
            <div className="progress-area">
              <span>
                {completed.length} / {chapters.length} MEMORIES
              </span>
              <div>
                <i style={{ width: `${(completed.length / chapters.length) * 100}%` }} />
              </div>
            </div>
            <div className="header-actions">
              <button
                className="sound-toggle-btn"
                onClick={() => {
                  const next = sounds.toggleMute();
                  setMuted(next);
                }}
                title={muted ? "Unmute audio" : "Mute audio"}
              >
                {muted ? "🔇 SFX OFF" : "🔊 SFX ON"}
              </button>
              <button
                className="icon-button"
                aria-label="Pause"
                onClick={() => {
                  sounds.playBeep();
                  setPaused(true);
                }}
              >
                II
              </button>
            </div>
          </header>
          <div className="map-intro">
            <p>Walk the path of our first year</p>
            <div className="map-party">
              <PixelCouple small />
              <span>SELECT AN UNLOCKED MEMORY TO ENTER</span>
            </div>
          </div>
          <div className="chapter-map">
            {visibleChapters.map((item, localIndex) => {
              const index = mapPage * MAP_PAGE_SIZE + localIndex;
              const locked = index > unlocked;
              const done = completed.includes(index);
              const regionStart = localIndex === 0 || chapters[index - 1].region !== item.region;
              return (
                <div
                  className={`map-entry ${locked ? "locked" : ""} ${done ? "done" : ""} ${item.region === "Thailand" ? "thailand-node" : ""}`}
                  key={`${item.title}-${index}`}
                >
                  {regionStart && (
                    <div className="region-marker">
                      <span>
                        WORLD{" "}
                        {String(
                          [
                            "Before Us",
                            "The Dance That Started It",
                            "The First Kiss",
                            "Festivals & Becoming Us",
                            "Dates & New Beginnings",
                            "Growing Side by Side",
                            "Thailand",
                            "Toward One Year",
                          ].indexOf(item.region) + 1,
                        ).padStart(2, "0")}
                      </span>
                      <h3>{item.region}</h3>
                    </div>
                  )}
                  <button
                    onClick={() => beginChapter(index)}
                    disabled={locked}
                    aria-label={`${locked ? "Locked: " : ""}${item.title}`}
                  >
                    <span className="node-line" />
                    <span className="node-orb">{done ? "✓" : locked ? "×" : index + 1}</span>
                    <span className="node-art">
                      <Icon name={item.icon} size={30} />
                    </span>
                    <span className="node-copy">
                      <small>CHAPTER {String(index + 1).padStart(2, "0")}</small>
                      <strong>{item.title}</strong>
                      <em>{locked ? "LOCKED" : item.place}</em>
                    </span>
                    {!locked && <span className="play-arrow">›</span>}
                  </button>
                </div>
              );
            })}
            {mapPage === MAP_PAGE_COUNT - 1 && (
              <div className="map-ending">
                <span>♦</span>
                <strong>ONE YEAR OF US</strong>
                <small>Complete every memory to unlock</small>
              </div>
            )}
          </div>
          <div className="map-bottom">
            <Controls compact />
            <div className="map-pager">
              <button
                onClick={() => {
                  sounds.playBeep();
                  setMapPage((page) => Math.max(0, page - 1));
                }}
                disabled={mapPage === 0}
              >
                ← PREVIOUS
              </button>
              <span>
                MEMORY PATH {mapPage + 1} / {MAP_PAGE_COUNT}
              </span>
              <button
                onClick={() => {
                  sounds.playBeep();
                  setMapPage((page) => Math.min(MAP_PAGE_COUNT - 1, page + 1));
                }}
                disabled={mapPage === MAP_PAGE_COUNT - 1}
              >
                NEXT →
              </button>
            </div>
          </div>
        </section>
      )}

      {screen === "game" && (
        <section className={`screen game-screen tone-${chapter.tone}`}>
          <header className="game-header gameplay-header">
            <button
              className="back-link"
              onClick={() => {
                sounds.playBeep();
                setScreen("map");
              }}
            >
              ← MAP
            </button>
            <div>
              <span>CHAPTER {String(active + 1).padStart(2, "0")} / 31</span>
              <strong>{chapter.title}</strong>
            </div>
            <div className="quest-progress">
              <span>MEMORY SHARDS</span>
              <i>
                {memory === null ? 0 : memory + 1} / {chapter.memories.length}
              </i>
            </div>
            <div className="header-actions">
              <button
                className="sound-toggle-btn"
                onClick={() => {
                  const next = sounds.toggleMute();
                  setMuted(next);
                }}
                title={muted ? "Unmute audio" : "Mute audio"}
              >
                {muted ? "🔇 SFX OFF" : "🔊 SFX ON"}
              </button>
              <button
                className="icon-button"
                onClick={() => {
                  sounds.playBeep();
                  setPaused(true);
                }}
              >
                II
              </button>
            </div>
          </header>
          {whisper && (
            <div className="whisper-popup" role="status">
              <span>💕</span>
              <span>{whisper}</span>
            </div>
          )}
          <div
            className="world-scene"
            onClick={(e) => {
              if (memory !== null) return;
              const target = e.target as HTMLElement;
              if (
                target.closest(".memory-object") ||
                target.closest(".interact-prompt") ||
                target.closest(".scene-controls")
              ) {
                return;
              }
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = ((e.clientX - rect.left) / rect.width) * 100;
              const clickY = ((e.clientY - rect.top) / rect.height) * 100;
              const targetX = Math.max(5, Math.min(92, Math.round(clickX)));
              const targetY = Math.max(20, Math.min(78, Math.round(clickY)));
              setFacing(targetX < pos.x ? "left" : "right");
              setIsMoving(true);
              sounds.playStep();
              setPos({ x: targetX, y: targetY });
              if (moveTimerRef.current) clearTimeout(moveTimerRef.current);
              moveTimerRef.current = setTimeout(() => setIsMoving(false), 240);
            }}
          >
            <SceneDecor chapter={chapter} />
            <div className="location-card">
              <span>NOW ENTERING</span>
              <strong>{chapter.place}</strong>
            </div>
            <div
              className={`memory-object object-one ${isNearObjectOne ? "in-range" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                sounds.playChime();
                setMemory(0);
              }}
              role="button"
              tabIndex={0}
              title="Click to Recall Memory Shard"
            >
              <span className="object-glow" />
              <Icon name={chapter.icon} size={36} />
              <b>!</b>
            </div>
            <div
              className={`memory-object object-two ${isNearObjectTwo ? "in-range" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                triggerWhisper();
              }}
              role="button"
              tabIndex={0}
              title="Click for Memory Sparkle"
            >
              <span className="object-glow" />
              <Icon name="spark" size={28} />
            </div>
            <div
              className={`player-sprite ${facing === "left" ? "facing-left" : ""}`}
              style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
            >
              <PixelCouple small walking={isMoving} />
              <span className="player-shadow" />
            </div>
            <button
              className={`interact-prompt ${isNearObjectOne ? "in-range-prompt" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                sounds.playChime();
                setMemory(0);
              }}
            >
              <kbd>ENTER</kbd> {isNearObjectOne ? "RECALL MEMORY SHARD ★" : "RECALL MEMORY"}
            </button>
            <div className="scene-controls">
              <Controls compact />
            </div>
          </div>
          {memory !== null && (
            <div className="memory-overlay" onClick={(e) => e.stopPropagation()}>
              <div className="memory-illustration">
                <div className="memory-couple">
                  <PixelCouple small />
                </div>
                <div className="memory-icon">
                  <Icon name={chapter.icon} size={58} />
                </div>
                <span>MEMORY SHARD {memory + 1}</span>
              </div>
              <div className="dialogue-box memory-box">
                <div className="speaker">
                  {memory % 2 ? "BILLO & PILLU" : active % 2 ? "SHRUTI" : "PRATEEK"}
                </div>
                <h2>{chapter.memories[memory].label}</h2>
                <p>{chapter.memories[memory].text}</p>
                <div className="dialogue-footer">
                  <span>
                    {memory + 1} / {chapter.memories.length}
                  </span>
                  <div style={{ display: "flex", gap: "8px" }}>
                    {memory > 0 && (
                      <button
                        onClick={() => {
                          sounds.playBeep();
                          setMemory(memory - 1);
                        }}
                      >
                        ◀ PREV
                      </button>
                    )}
                    <button
                      onClick={() => {
                        sounds.playBeep();
                        memory < chapter.memories.length - 1
                          ? setMemory(memory + 1)
                          : finishChapter();
                      }}
                    >
                      {memory < chapter.memories.length - 1
                        ? "CONTINUE"
                        : active === chapters.length - 1
                          ? "FINISH OUR YEAR"
                          : "MEMORY COMPLETE"}{" "}
                      <b>↵</b>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {screen === "ending" && (
        <section className="screen ending-screen">
          <Stars />
          <div className="ending-moon" />
          <div className="ending-city" />
          <div className="ending-content">
            <span className="eyebrow">LEVEL 1 COMPLETE</span>
            <h2>
              ONE YEAR
              <br />
              <i>of us</i>
            </h2>
            <PixelCouple />
            <div className="ending-message">
              <span className="tiny-heart">♥</span>
              <p>
                From a practice room to a whole world of our own—through every celebration, every
                hard day, every laugh, and every quiet moment—thank you for choosing us.
              </p>
              <strong>
                One year down.
                <br />A lifetime of adventures to go.
              </strong>
            </div>
            <button
              className="pixel-button primary"
              onClick={() => {
                sounds.playBeep();
                setScreen("title");
              }}
            >
              OUR NEXT CHAPTER <span>→</span>
            </button>
            <button
              className="text-button"
              onClick={() => {
                sounds.playBeep();
                setScreen("map");
              }}
            >
              REVISIT OUR MEMORIES
            </button>
          </div>
        </section>
      )}

      {paused && (
        <div className="pause-overlay">
          <div className="pause-card">
            <span className="eyebrow">GAME PAUSED</span>
            <h2>
              TAKE A BREATH,
              <br />
              <i>LOVE QUEST AWAITS.</i>
            </h2>
            <button
              className="pixel-button primary"
              onClick={() => {
                sounds.playBeep();
                setPaused(false);
              }}
            >
              RESUME
            </button>
            <button
              className="pixel-button secondary"
              onClick={() => {
                sounds.playBeep();
                setPaused(false);
                setScreen("map");
              }}
            >
              MEMORY MAP
            </button>
            <button
              className="pixel-button secondary"
              onClick={() => {
                const next = sounds.toggleMute();
                setMuted(next);
              }}
            >
              {muted ? "🔇 UNMUTE AUDIO" : "🔊 MUTE AUDIO"}
            </button>
            <button
              className="text-button"
              onClick={() => {
                if (window.confirm("Reset all unlocked memories and restart from Chapter 1?")) {
                  sounds.playBeep();
                  setCompleted([]);
                  setActive(0);
                  setMapPage(0);
                  setPaused(false);
                  setScreen("title");
                }
              }}
              style={{ color: "#d57a8a" }}
            >
              RESET GAME PROGRESS
            </button>
            <button
              className="text-button"
              onClick={() => {
                sounds.playBeep();
                setPaused(false);
                setScreen("title");
              }}
            >
              SAVE & EXIT TO TITLE
            </button>
            <Controls compact />
          </div>
        </div>
      )}
    </main>
  );
}

function SceneDecor({ chapter }: { chapter: Chapter }) {
  const thailand = chapter.region === "Thailand";
  const forest = chapter.tone === "forest";
  const festival = ["saffron", "pink", "colour", "nightfair"].includes(chapter.tone);
  const dance = chapter.region === "The Dance That Started It";
  const intimate = chapter.region === "The First Kiss";
  const ocean = chapter.tone === "ocean";
  const cozy = ["key", "book", "gift", "cake", "home", "clay"].includes(chapter.icon);
  return (
    <div
      className={`scene-decor theme-${chapter.icon} ${thailand ? "is-thailand" : ""} ${
        dance ? "is-dance" : ""
      } ${intimate ? "is-intimate" : ""} ${ocean ? "is-ocean" : ""} ${cozy ? "is-cozy" : ""}`}
    >
      <Stars />
      <div className="atmosphere">
        <i />
        <i />
        <i />
      </div>
      <div className="sky-orb" />
      {thailand ? (
        <>
          <div className="bangkok-sign">
            BANGKOK
            <br />
            <small>AFTER DARK</small>
          </div>
          <div className="neon-shop">
            <span>24</span>
            <b>SEVEN ELEVEN</b>
          </div>
          <div className="street-lamps">
            <i />
            <i />
            <i />
          </div>
          <div className="wet-street">
            <i />
            <i />
            <i />
          </div>
        </>
      ) : forest ? (
        <>
          <div className="mountains" />
          <div className="trees">
            {Array.from({ length: 9 }, (_, i) => (
              <i key={i} />
            ))}
          </div>
          <div className="cave">KANHERI</div>
          <div className="forest-lanterns">
            <i />
            <i />
            <i />
          </div>
        </>
      ) : festival ? (
        <>
          <div className="festival-lights">
            {Array.from({ length: 13 }, (_, i) => (
              <i key={i} />
            ))}
          </div>
          <div className="temple-silhouette">
            <span />
            <b />
          </div>
          <div className="rangoli">
            <i />
          </div>
          {chapter.icon === "wheel" && (
            <div className="ferris-wheel">
              <i />
            </div>
          )}
        </>
      ) : ocean ? (
        <>
          <div className="sea-horizon">
            <i />
            <i />
            <i />
          </div>
          <div className="marine-rail" />
          <div className="city-shore" />
        </>
      ) : intimate ? (
        <div className="room-wall">
          <span className="room-window" />
          <span className="fairy-lights" />
          <span className="bed">
            <i />
            <b />
          </span>
        </div>
      ) : dance ? (
        <>
          <div className="campus-stage">
            <span>VIVEKANAND</span>
            <i />
            <i />
            <i />
          </div>
          <div className="stage-lights">
            <i />
            <i />
            <i />
          </div>
        </>
      ) : cozy ? (
        <div className="cozy-interior">
          <span className="cafe-window" />
          <span className="shelf">
            <i />
            <i />
            <i />
            <i />
          </span>
          <span className="cafe-table">
            <i />
          </span>
          <span className="floor-lamp" />
        </div>
      ) : (
        <>
          <div className="pixel-buildings">
            <i />
            <i />
            <i />
            <i />
            <i />
          </div>
          <div className="window-lights">
            {Array.from({ length: 18 }, (_, i) => (
              <i key={i} />
            ))}
          </div>
        </>
      )}
      <div className="pathway" />
      <div className="pixel-petals">
        {Array.from({ length: 8 }, (_, i) => (
          <i key={i} />
        ))}
      </div>
      <div className="foreground-plants">
        <i />
        <i />
        <i />
        <i />
      </div>
    </div>
  );
}
